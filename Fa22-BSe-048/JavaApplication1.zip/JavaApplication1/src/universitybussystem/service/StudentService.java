package universitybussystem.service;

import universitybussystem.entities.BusPass;
import universitybussystem.entities.Student;
import universitybussystem.util.Subject;

public class StudentService extends Subject {
    public BusPass applyForBusPass(Student student, String validityPeriod) {
        BusPass busPass = new BusPass("PASS-" + student.getStudentID(), student.getStudentID(), validityPeriod);
        student.setBusPass(busPass);
        notifyObservers("Bus pass issued for Student " + student.getName());
        return busPass;
    }
}
