package universitybussystem.util;

public interface Observer {
    void update(String message);
}
