package universitybussystem.util;

public interface Filter<T> {
    void process(Pipe<T> pipe);
}
