package universitybussystem.filters;

import universitybussystem.entities.Student;
import universitybussystem.util.Filter;
import universitybussystem.util.Pipe;

public class ValidationFilter implements Filter<Student> {
    @Override
    public void process(Pipe<Student> pipe) {
        Student student = pipe.getData();
        if (student.getContactInfo() == null || student.getName() == null) {
            throw new IllegalArgumentException("Invalid Student Details");
        }
    }
}
