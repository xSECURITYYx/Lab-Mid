package universitybussystem.entities;

public class BusPass {
    private String passID;
    private String studentID;
    private String validityPeriod;

    public BusPass(String passID, String studentID, String validityPeriod) {
        this.passID = passID;
        this.studentID = studentID;
        this.validityPeriod = validityPeriod;
    }

    public String getPassID() {
        return passID;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getValidityPeriod() {
        return validityPeriod;
    }

    public void renewPass(String newValidityPeriod) {
        this.validityPeriod = newValidityPeriod;
    }
}
