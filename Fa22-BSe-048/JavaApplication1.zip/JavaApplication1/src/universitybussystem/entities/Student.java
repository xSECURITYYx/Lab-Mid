package universitybussystem.entities;

import universitybussystem.util.Observer;

public class Student implements Observer {
    private String studentID;
    private String name;
    private String contactInfo;
    private BusPass busPass;

    public Student(String studentID, String name, String contactInfo) {
        this.studentID = studentID;
        this.name = name;
        this.contactInfo = contactInfo;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getName() {
        return name;
    }

    public String getContactInfo() {
        return contactInfo;
    }

    public BusPass getBusPass() {
        return busPass;
    }

    public void setBusPass(BusPass busPass) {
        this.busPass = busPass;
    }

    @Override
    public void update(String message) {
        System.out.println("Notification for Student " + name + ": " + message);
    }
}
