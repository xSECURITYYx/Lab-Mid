package universitybussystem.presentation;

import universitybussystem.entities.Student;
import universitybussystem.filters.ValidationFilter;
import universitybussystem.util.Pipe;

public class Main {
    public static void main(String[] args) {
        try {
            Student student = new Student("S001", "Alice", null);

            Pipe<Student> pipe = new Pipe<>();
            pipe.setData(student);

            ValidationFilter validationFilter = new ValidationFilter();
            validationFilter.process(pipe);

            System.out.println("Validation passed!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
